package com.example.cameralockdemo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat

class CameraBlockerService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val checkInterval = 500L // Check every 500ms
    private var isRunning = false

    private val CAMERA_PACKAGES = listOf(
        "com.android.camera",
        "com.google.android.GoogleCamera",
        "com.samsung.android.camera",
        "com.sec.android.app.camera",
        "com.xiaomi.camera",
        "com.huawei.camera",
        "com.oppo.camera",
        "com.oneplus.camera",
        "com.motorola.camera2",
        "com.asus.camera",
        "com.sonyericsson.android.camera",
        "org.codeaurora.snapcam"
    )

    private val runnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            checkForegroundApp()
            handler.postDelayed(this, checkInterval)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundService()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!isRunning) {
            isRunning = true
            handler.post(runnable)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        handler.removeCallbacks(runnable)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun startForegroundService() {
        val channelId = "CameraBlockerChannel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Camera Blocker Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Camera Lock Active")
            .setContentText("Monitoring for camera usage...")
            .setSmallIcon(R.mipmap.ic_launcher)
            .build()

        startForeground(1, notification)
    }

    private fun checkForegroundApp() {
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val time = System.currentTimeMillis()
        var currentApp = ""
        
        // Strategy 1: Usage Events (Precise)
        val events = usageStatsManager.queryEvents(time - 2000, time) // 2 seconds window
        val event = android.app.usage.UsageEvents.Event()
        var lastEventTime = 0L

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND) {
                currentApp = event.packageName
                lastEventTime = event.timeStamp
            }
        }

        // Strategy 2: Usage Stats Snapshot (Fallback if Events are empty/missed)
        if (currentApp.isEmpty()) {
             val stats = usageStatsManager.queryUsageStats(
                 UsageStatsManager.INTERVAL_DAILY,
                 time - 1000 * 10,
                 time
             )
             if (stats != null && stats.isNotEmpty()) {
                 val sortedStats = stats.sortedByDescending { it.lastTimeUsed }
                 if (sortedStats.isNotEmpty()) {
                     currentApp = sortedStats[0].packageName
                 }
             }
        }

        if (currentApp.isNotEmpty()) {
            if (isCameraApp(currentApp)) {
                Log.d("CameraBlocker", "Camera detected: $currentApp")
                blockCamera()
            }
        }
    }

    private fun isCameraApp(packageName: String): Boolean {
        // 1. Explicitly ignore OUR app
        if (packageName == applicationContext.packageName) return false
        
        // 2. Check known list
        if (CAMERA_PACKAGES.contains(packageName)) return true
        
        // 3. Check if package name contains "camera" (heuristic)
        // This is risky but catches many 3rd party cameras.
        // We MUST ensure we don't catch ourselves.
        if (packageName.contains("camera", ignoreCase = true)) {
            // Double check it's not us (redundant but safe)
            if (packageName != applicationContext.packageName) {
                return true
            }
        }
        
        return false
    }

    private fun blockCamera() {
        // Double check Overlay Permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) {
            Log.e("CameraBlocker", "Cannot block camera: Overlay permission missing")
            return
        }

        try {
            val intent = Intent(this, BlockedActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            startActivity(intent)
        } catch (e: Exception) {
            Log.e("CameraBlocker", "Failed to start BlockedActivity", e)
        }
    }
}