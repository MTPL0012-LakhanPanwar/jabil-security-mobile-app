package com.example.cameralockdemo

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.cameralockdemo.api.RetrofitClient
import com.example.cameralockdemo.api.models.DeviceInfo
import com.example.cameralockdemo.api.models.ScanEntryRequest
import com.example.cameralockdemo.api.models.ScanExitRequest
import com.example.cameralockdemo.manager.DeviceAdminManager
import com.example.cameralockdemo.utils.Constants
import com.example.cameralockdemo.utils.DeviceUtils
import com.google.zxing.integration.android.IntentIntegrator
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException

class MainActivity : AppCompatActivity() {
    
    companion object {
        private const val TAG = "MainActivity"
    }
    
    // UI Components
    private lateinit var tvStatus: TextView
    private lateinit var tvStatusMessage: TextView
    private lateinit var ivStatusIcon: ImageView
    private lateinit var btnScanEntry: Button
    private lateinit var btnScanExit: Button
    private lateinit var btnTestCamera: Button
    private lateinit var tvFooter: TextView
    
    // Managers
    private lateinit var deviceAdminManager: DeviceAdminManager
    
    // Current QR scan action
    private var currentScanAction: ScanAction = ScanAction.NONE
    private enum class ScanAction { NONE, ENTRY, EXIT }
    
    
    // ==================== Lifecycle Methods ====================
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        // Initialize managers
        deviceAdminManager = DeviceAdminManager(this)
        
        // Initialize UI
        initializeViews()
        setupClickListeners()
        
        // Update UI
        updateUI()
        
        // Check camera permission
        checkCameraPermission()
    }
    
    override fun onResume() {
        super.onResume()
        updateUI()
    }
    
    
    // ==================== UI Initialization ====================
    
    private fun initializeViews() {
        tvStatus = findViewById(R.id.tvStatus)
        tvStatusMessage = findViewById(R.id.tvStatusMessage)
        ivStatusIcon = findViewById(R.id.ivStatusIcon)
        btnScanEntry = findViewById(R.id.btnScanEntry)
        btnScanExit = findViewById(R.id.btnScanExit)
        btnTestCamera = findViewById(R.id.btnTestCamera)
        tvFooter = findViewById(R.id.tvFooter)
        
        // Set device info
        tvFooter.text = "Device: ${DeviceUtils.getDeviceDescription()}"
    }
    
    private fun setupClickListeners() {
        btnScanEntry.setOnClickListener {
            if (checkCameraPermission()) {
                currentScanAction = ScanAction.ENTRY
                startQRScan()
            }
        }
        
        btnScanExit.setOnClickListener {
            // Temporarily unlock camera to allow scanning
            if (deviceAdminManager.isCameraLocked()) {
                deviceAdminManager.unlockCamera()
            }
            
            if (checkCameraPermission()) {
                currentScanAction = ScanAction.EXIT
                startQRScan()
            }
        }
        
        btnTestCamera.setOnClickListener {
            testCamera()
        }
    }
    
    private fun updateUI() {
        val isLocked = deviceAdminManager.isCameraLocked()
        val isAdmin = deviceAdminManager.isDeviceAdminActive()
        
        // Colors
        val colorLocked = ContextCompat.getColor(this, R.color.state_locked)
        val colorUnlocked = ContextCompat.getColor(this, R.color.state_unlocked)
        
        if (isLocked) {
            // LOCKED STATE
            tvStatus.text = "LOCKED"
            tvStatus.setTextColor(colorLocked)
            ivStatusIcon.setColorFilter(colorLocked)
            tvStatusMessage.text = getString(R.string.info_camera_locked)
            
            btnScanEntry.visibility = View.GONE
            btnScanExit.visibility = View.VISIBLE
        } else {
            // UNLOCKED STATE
            tvStatus.text = "UNLOCKED"
            tvStatus.setTextColor(colorUnlocked)
            ivStatusIcon.setColorFilter(colorUnlocked)
            tvStatusMessage.text = getString(R.string.info_camera_unlocked)
            
            btnScanEntry.visibility = View.VISIBLE
            btnScanExit.visibility = View.GONE
        }
        
        // Debug info if needed
        Log.d(TAG, "UI Updated: Locked=$isLocked, Admin=$isAdmin")
    }
    
    
    // ==================== Camera Permission ====================
    
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            // Permission granted, proceed with scan
            // Re-lock if we were trying to exit and user denied permission
            if (currentScanAction == ScanAction.EXIT) {
                deviceAdminManager.lockCamera()
                updateUI()
            }
            if (currentScanAction != ScanAction.NONE) {
                startQRScan()
            }
        } else {
            Toast.makeText(this, R.string.camera_permission_required, Toast.LENGTH_LONG).show()
        }
    }
    
    private fun checkCameraPermission(): Boolean {
        return if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            true
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
            false
        }
    }
    
    
    // ==================== QR Scanning ====================
    
    private fun startQRScan() {
        val integrator = IntentIntegrator(this)
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
        integrator.setPrompt("Scan ${if (currentScanAction == ScanAction.ENTRY) "Entry" else "Exit"} QR Code")
        integrator.setCameraId(0)
        integrator.setBeepEnabled(true)
        integrator.setBarcodeImageEnabled(false)
        integrator.initiateScan()
    }
    
    // Handle QR Scan Result
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        // Handle QR Result
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            if (result.contents != null) {
                handleScanResult(result.contents)
            } else {
                Toast.makeText(this, "Scan Cancelled", Toast.LENGTH_SHORT).show()
                
                // Re-lock if cancelled during Exit flow
                if (currentScanAction == ScanAction.EXIT) {
                    deviceAdminManager.lockCamera()
                    updateUI()
                }
            }
            return
        }
        
        // Handle Device Admin Result
        if (requestCode == Constants.DEVICE_ADMIN_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK || deviceAdminManager.isDeviceAdminActive()) {
                // Admin granted, lock camera
                lockCamera()
            } else {
                Toast.makeText(this, "Device admin permission denied", Toast.LENGTH_SHORT).show()
            }
            return
        }
        
        super.onActivityResult(requestCode, resultCode, data)
    }
    
    private fun handleScanResult(qrContent: String) {
        // Show loading state
        setLoading(true)
        
        lifecycleScope.launch {
            try {
                when (currentScanAction) {
                    ScanAction.ENTRY -> processEntryScan(qrContent)
                    ScanAction.EXIT -> processExitScan(qrContent)
                    else -> {}
                }
            } catch (e: Exception) {
                handleApiError(e)
            } finally {
                setLoading(false)
                currentScanAction = ScanAction.NONE
            }
        }
    }
    
    private suspend fun processEntryScan(token: String) {
        val deviceId = DeviceUtils.getDeviceId(this)
        val deviceInfo = DeviceInfo(
            manufacturer = android.os.Build.MANUFACTURER,
            model = android.os.Build.MODEL,
            osVersion = android.os.Build.VERSION.RELEASE,
            platform = "android",
            appVersion = Constants.APP_VERSION,
            deviceName = android.os.Build.DEVICE
        )
        
        val request = ScanEntryRequest(
            token = token,
            deviceId = deviceId,
            deviceInfo = deviceInfo
        )
        
        val response = RetrofitClient.apiService.scanEntry(request)
        
        if (response.isSuccessful && response.body()?.status == "success") {
            // API validated -> Request Admin / Lock
            requestDeviceAdmin()
        } else {
            showErrorDialog(response.body()?.message ?: "Entry failed. Please try again.")
        }
    }
    
    private suspend fun processExitScan(token: String) {
        val deviceId = DeviceUtils.getDeviceId(this)
        
        val request = ScanExitRequest(
            token = token,
            deviceId = deviceId
        )
        
        val response = RetrofitClient.apiService.scanExit(request)
        
        if (response.isSuccessful && response.body()?.status == "success") {
            // API validated -> Unlock
            unlockAndRemoveAdmin()
        } else {
            showErrorDialog(response.body()?.message ?: "Exit failed. Please try again.")
            // Validation failed, re-lock
            deviceAdminManager.lockCamera()
            updateUI()
        }
    }
    
    private fun handleApiError(e: Exception) {
        val message = when (e) {
            is IOException -> Constants.ERROR_NO_INTERNET
            is HttpException -> "Server error: ${e.code()}"
            else -> e.message ?: "Unknown error occurred"
        }
        showErrorDialog(message)
        
        // If error occurred during Exit, re-lock
        if (currentScanAction == ScanAction.EXIT) {
            deviceAdminManager.lockCamera()
            updateUI()
        }
    }
    private fun setLoading(isLoading: Boolean) {
        btnScanEntry.isEnabled = !isLoading
        btnScanExit.isEnabled = !isLoading
        if (isLoading) {
            tvStatusMessage.text = "Processing..."
        } else {
            // Restore status text based on current state
            updateUI()
        }
    }
    
    
    // ==================== Business Logic ====================
    
    private fun requestDeviceAdmin() {
        // 1. Check Overlay Permission (Required for Android 10+ Background Start)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("Permission Required")
                .setMessage("To block the camera effectively, we need 'Display over other apps' permission.\n\nPlease find '${getString(R.string.app_name)}' in the list and enable it.")
                .setPositiveButton("Grant") { _, _ ->
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName"))
                    startActivity(intent)
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }

        // 2. Check Usage Stats Permission (for Service Blocker)
        if (!hasUsageStatsPermission()) {
            AlertDialog.Builder(this)
                .setTitle("Permission Required")
                .setMessage("To detect when the camera is opened, we need 'Usage Access' permission.\n\nPlease find '${getString(R.string.app_name)}' in the list and enable it.")
                .setPositiveButton("Grant") { _, _ ->
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }

        // 3. Check Device Admin (for Legacy Hardware Lock)
        if (!deviceAdminManager.isDeviceAdminActive()) {
            val intent = deviceAdminManager.requestDeviceAdminPermission()
            startActivityForResult(intent, Constants.DEVICE_ADMIN_REQUEST_CODE)
        } else {
            // Already admin, just lock
            lockCamera()
        }
    }
    
    private fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        val mode = appOps.checkOpNoThrow(
            android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        )
        return mode == android.app.AppOpsManager.MODE_ALLOWED
    }
    
    private fun lockCamera() {
        // 1. Try Hardware Lock (Legacy)
        var hardwareLockSuccess = false
        try {
            hardwareLockSuccess = deviceAdminManager.lockCamera()
        } catch (e: Exception) {
            Log.e(TAG, "Hardware lock failed", e)
        }

        // 2. Start Software Lock (Service) - Always start this as backup/primary
        try {
            val serviceIntent = Intent(this, CameraBlockerService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start blocker service", e)
        }

        showSuccessDialog("Camera Locked", Constants.SUCCESS_CAMERA_LOCKED + "\n(Active via Service & Admin)")
        updateUI()
    }
    
    private fun unlockAndRemoveAdmin() {
        // 1. Stop Software Lock (Service)
        stopService(Intent(this, CameraBlockerService::class.java))

        // 2. Unlock Hardware
        if (deviceAdminManager.unlockCamera()) {
            // Try to remove admin
            if (deviceAdminManager.removeDeviceAdmin()) {
                showSuccessDialog("Camera Unlocked", Constants.SUCCESS_CAMERA_UNLOCKED)
            } else {
                showSuccessDialog("Camera Unlocked", "You are checked out. Please manually remove device admin permission if prompted.")
            }
            updateUI()
        } else {
            // Even if hardware unlock fails (maybe it wasn't locked), we stopped the service, so we are good.
            showSuccessDialog("Camera Unlocked", Constants.SUCCESS_CAMERA_UNLOCKED)
            updateUI()
        }
    }
    
    private fun testCamera() {
        try {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                // If camera is disabled, resolveActivity might return null or throw
                Toast.makeText(this, "Unable to launch camera app (it might be disabled)", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error launching camera: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    
    private fun showSuccessDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .setIcon(R.drawable.ic_logo)
            .show()
    }
    
    private fun showErrorDialog(message: String) {
        AlertDialog.Builder(this)
            .setTitle("Error")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .setIcon(android.R.drawable.ic_dialog_alert)
            .show()
    }
}
